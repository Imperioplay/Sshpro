# REYSSH ⚡

# @IMPERIO_WEB

*PROJETO EM BETA🍷🗿
```
apt install wget -y; bash <(wget -qO- raw.githubusercontent.com/Imperioplay/Sshpro/main/ssh-plus)

```
